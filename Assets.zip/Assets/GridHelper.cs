﻿using UnityEngine;
using System.Collections;

public class GridHelper : MonoBehaviour {
    public int radius;

	// Use this for initialization
	void Start () {
        radius = 3;

	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
