﻿using UnityEngine;
using System.Collections;

public class CamMovement : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		movement();
	}
	
	void movement(){
		Vector3 move = new Vector3(Input.GetAxis("Horizontal"), 0f, Input.GetAxis("Vertical"));
		Vector3 rot = new Vector3(0f, Input.GetAxis("Horizontal2"), 0f);
		move.Normalize();
		transform.Translate(move);
		transform.Rotate(rot);
	}
}
