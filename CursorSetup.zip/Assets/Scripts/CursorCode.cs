﻿using UnityEngine;
using System.Collections;

public class CursorCode : MonoBehaviour {

	GameObject active;
	public GameObject cam;
	void Start () {
		
	}
	

	void Update () {
		move();
		if (Input.GetButton("Fire2") && active != null){
			active = null;
		}
	}
	
	void move(){	
		transform.LookAt(cam.transform.position);
		LayerMask layer = 1 << 8;

		RaycastHit hit;
		if (Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out hit, Mathf.Infinity, layer)){
			transform.position = hit.point;
		}
	}
	
	
	void OnCollisionStay(Collision c){	
		
		if (Input.GetButton("Fire1") && active == null){
			active = c.gameObject;
		}
	}
	
}
