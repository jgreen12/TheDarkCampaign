using UnityEngine;
using System.Collections;

public class camBehaviorN : MonoBehaviour {

	void Update () {
		Vector3 movement = new Vector3(0f, 0f, Input.GetAxis("Vertical2"));
		Vector3 pos = transform.position;
		pos.y = Mathf.Clamp(transform.position.y, 1.5f, 10f);
		transform.position = pos;	
		transform.Translate(movement);
	}
}
