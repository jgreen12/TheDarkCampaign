using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class characterOptionMenuN : MonoBehaviour {
	
	public GameObject gController;
	public GameObject cursor;
	public GameObject unit;
	public Text t;
	
	void Start(){
		gController = GameObject.Find("gameController");
		cursor = GameObject.Find("cursor");
		unit = gController.GetComponent<gameControllerN>().activeUnit;
		transform.position = Input.mousePosition + new Vector3(75f, 0f, 0f);
		t.text = unit.GetComponent<unitBehaviorN>().character;
	}
	void Update(){
		//unit = gController.GetComponent<gameControllerN>().activeUnit;
		if (Input.GetButtonDown("Fire2")){
			Destroy(this.gameObject);
		}
	}
	
	public void move(){
		if (!unit.GetComponent<unitBehaviorN>().moved){
			cursor.GetComponent<cursorCodeN>().activeMove = true;
			unit.GetComponent<unitBehaviorN>().moved = true;
		}
	}
	
	public void attack(){
		if (!unit.GetComponent<unitBehaviorN>().attacked){
			cursor.GetComponent<cursorCodeN>().activeAttack = true;
			unit.GetComponent<unitBehaviorN>().attacked = true;
		}
	}
	
	public void wait(){
		gController.GetComponent<gameControllerN>().nextTurn();
		cursor.GetComponent<cursorCodeN>().menu = false;
		Destroy(this.gameObject);
	}
}