using UnityEngine;
using System.Collections;

public class cursorCodeN : MonoBehaviour {
	
	public GameObject gameController;
	public GameObject activeUnit;//unit who is taking their turn
	public GameObject activeTile;//tile the cursor is over
	public GameObject cam;
	private GameObject tempUnit;
	public bool active = true;//whether the player has control of cursor
	public bool activeMove = false;//true if move button is clicked
	public bool activeAttack = false;//true if attack button is clicked
	public bool menu = false;
	public GameObject gui;
	
	void Update (){
		if (active)
			Default();
		activeUnit = gameController.GetComponent<gameControllerN>().activeUnit;
		if (activeMove){
			if (Input.GetButtonDown("Fire1"))
				move();
		}
		if (activeAttack){
			if (Input.GetButtonDown("Fire1") && tempUnit != null)
				attackf();
		}
	}
	
	void Default(){	
		Vector3 focus = new Vector3(cam.transform.position.x, transform.position.y, cam.transform.position.z);
		transform.LookAt(focus);
		LayerMask layer = 1 << 8;
		RaycastHit hit;
		if (Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out hit, Mathf.Infinity, layer)){
			transform.position = hit.point;
		}
		
		if (!menu && Input.GetButtonDown("Fire1")){
			gui.GetComponent<GUI>().createMenu();
			menu = true;
		}
		else if (menu && Input.GetButtonUp("Fire2")){
			tempUnit = null;
			menu = false;
		}
	}
	
	void OnTriggerStay(Collider c){
		GameObject temp = c.gameObject;
		if (temp.tag == "unit"){
			tempUnit = c.gameObject;
		}
		if (temp.tag == "tile"){
			activeTile = c.gameObject;
		}
		
	}
	
	public void move() {
		activeUnit.transform.position = activeTile.transform.position;
		activeMove = false;
	}
	
	public void attackf(){
		gameController.GetComponent<gameControllerN>().basicAttack(activeUnit, tempUnit);
	}
}
