using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class GUI : MonoBehaviour{
	
	public Image characterMenu;
	
	public void createMenu(){
		Image i = Instantiate(characterMenu) as Image;
		i.transform.SetParent(this.transform, false);
	}
}