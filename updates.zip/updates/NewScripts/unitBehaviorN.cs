using UnityEngine;
using System.Collections;

public class unitBehaviorN : MonoBehaviour {
	
	public string character = "unit";
	public int HP = 50;
	public int str = 20;
	public int agi = 7;
	public int initiative = 10;
	
	public bool myTurn;
	public bool attacked = false;
	public bool moved = false;
	//public bool allignment;//on your team or not;
	
	public void turnStart(){
		myTurn = true;
		attacked = false;
		moved = false;
	}
	
	public void turnEnd(){
		myTurn = false;
	}
}