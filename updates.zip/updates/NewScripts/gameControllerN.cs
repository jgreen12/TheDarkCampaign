using UnityEngine;
using System.Collections;

public class gameControllerN : MonoBehaviour{
	
	public GameObject[] units;
	public GameObject activeUnit;
	public int encounterSize;
	public int turn = 0;
	
	void Start(){
		turn = 0;
		encounterSize = units.Length;
		activeUnit = units[turn];
		activeUnit.GetComponent<unitBehaviorN>().turnStart();
	}
	
	public void nextTurn(){
		activeUnit.GetComponent<unitBehaviorN>().turnEnd();
		turn++;
		int i = turn % units.Length;
		activeUnit = units[i];
		units[i].GetComponent<unitBehaviorN>().turnStart();
	}
	
	public void basicAttack(GameObject attacker, GameObject defender){
		int range = 1;
		int a = attacker.GetComponent<unitBehaviorN>().str;
		defender.GetComponent<unitBehaviorN>().HP -= a - (a * (int)(Random.value * 255))/512;
	}
	
	public void basicRangedAttack(GameObject attacker, GameObject defender){
	}
}