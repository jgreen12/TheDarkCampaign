using UnityEngine;
using System.Collections;

public class camMovementN : MonoBehaviour {
	void Update(){
		Vector3 move = new Vector3(Input.GetAxis("Horizontal"), 0f, Input.GetAxis("Vertical"));
		Vector3 rot = new Vector3(0f, Input.GetAxis("Horizontal2"), 0f);
		move.Normalize();
		transform.Translate(move);
		transform.Rotate(rot);
	}
}